/***************************************************************

                SpaceDynX, pre-release

*****************************************************************

CALC_JTE	Translational Jacobians w.r.t. the End-point
                                          specified by 'number'

		input:
			A0 - orientation of the base wrt to inertia frame
                             (3 by 3 direction cosines matrix)
			q  - joint angles
			R0 - base position
			num_e - number of end-effector

	        global Qi J_type BB SS SE S0 Qe
	        global cc c0 ce Ez
		global m0 inertia0 m inertia

		uses calc_a, calc_pos, j_num, f_kin_j, f_kin_e

*****************************************************************/

	Func Matrix calc_jte( R0 , A0 , q, num_e )
	Matrix  R0, A0, q;
	Integer num_e;

	{		
	Matrix  joint, JJ_re; 
	Integer num_q, n, k, i, joint_i;
	Matrix  RR, AA, JJ_te, temp;
	Matrix  POS_j, POS_e, ORI_j, ORI_e, A_I_i; 

	num_q = length(q);//number of links

	//Calculation of coordinate transfromation matrices 
	AA = calc_aa( A0, q );

	//Calculation of position vectors
	RR = calc_pos( R0, A0, q );

	//Find link connection from the End-link to zero
	joint = j_num(num_e);

	n = length(joint);    //Check number of joint
	k = Integer( joint(n) );

	  if ( num_q == 0 ) { //Single or multi body ?
	    JJ_te = [];       //If a Single body,

	  } else {            // If a Multi body system,

	//Calculation of Joint Position
            { POS_j, ORI_j } = f_kin_j( R0, A0, q, num_e );

	//Calculation of End Point Position
            { POS_e, ORI_e } = f_kin_e( R0, A0, q, num_e );
	       
            JJ_te = [];

              for ( i=1; i<=n; i++ ) {
                joint_i = Integer( joint(i) );  
	        A_I_i = AA( :, joint_i*3-2 : joint_i*3 );

	        if ( j_type(joint_i) == "R" ) {

	//Rotational joint
                  temp = cross( (A_I_i * Ez), ( POS_e - POS_j(:,i) ) ); 
                  JJ_te = [ JJ_te temp ];

	        } else {

	//Prismatic joint
	          JJ_te = [ JJ_te A_I_i*Ez ];

	        }
	        //i = i+1;
	     }
	  }

	
	return JJ_te;
	}


