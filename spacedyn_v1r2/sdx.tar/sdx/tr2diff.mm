/***************************************************************

                SpaceDynX, pre-release

*****************************************************************

TR2DIFF 	Calculate difference between two transformation matrices
		in the form of roll/pitch/yaw angles.
		This computation is true only for small angles,
		and fails on singularity at the angle pi (180 deg).

		global	none
		uses	cross

*****************************************************************/

	Func Matrix tr2diff( TR1, TR2 )
	Matrix TR1, TR2;
	{
	Matrix diff;

	diff = [   cross( TR2(1 : 3, 1), TR1(1 : 3,1) ) + 
		   cross( TR2(1 : 3, 2), TR1(1 : 3,2) ) + 
		   cross( TR2(1 : 3, 3), TR1(1 : 3,3) )  ]/2;
	return diff;
	}