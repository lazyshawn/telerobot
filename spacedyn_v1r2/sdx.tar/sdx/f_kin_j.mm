/***************************************************************

                SpaceDynX, pre-release

*****************************************************************



F_KINE_J	Forward Kinematics:
		Caluculate the Position/Orientation of the joints 
		corresponding the End-point specified by 'num_e.'
	        POS : 3x1 vector, ORI : 3x3 matrix,
		POS_j : 3xn, ORI : 3x3n, 
		where n : num_e of joints between the End-point to link 0. 

		input:
			A0 - orientation of the base wrt to inertia frame
                             (3 by 3 direction cosines matrix)
			q  - joint angles
			R0 - base position
			num_e - number of end-effector

		global Qi J_type BB
		global cc c0 ce SE Qe

		uses  calc_aa, calc_pos, j_num

*****************************************************************/

	Func List f_kin_j( R0, A0, q, num_e )
	Integer num_e;
	Matrix  R0, A0, q;
	{
	Matrix  A_I_i, AA, POS, RR, ORI_tmp;
        Matrix  joint, POS_j, ORI_j, POS_tmp;
	Integer  i, k, n, num_q, p, j, l, joint_k;  

	num_q = length(q); //Check number of all joints

	//Calculation of coordinate transfromation matrices
                                             //on Inertia Frame
	AA = calc_aa( A0, q );

	//Calculation of position vectors in the Inertia Frame
	RR = calc_pos( R0, A0, q );

	//Calculate position vector of Joint i
        p = Cols(cc);
        p = p/num_q;
	
          for ( i = 1 ; i <= num_q ; i++ ) {  

            l = p*(i-1) + i;  
            A_I_i = AA( :, i*3-2 : i*3 );
            POS(:,i) = ( RR(:,i) + A_I_i*cc(:,l) );
	  }

	//Find joint connection from End-link to zero
	joint = j_num(num_e);

	//Check the number of the corresponding joints
	n = length(joint);

	//Calculation of Orientation and Position of each joints
	k = 0;
	POS_j = [];
	ORI_j = [];

	  for ( k = 1; k <= n; k++ ) {
            joint_k = Integer(joint(k)); 
            ORI_tmp = AA( :, joint_k*3-2 : joint_k*3);
            POS_tmp = POS( :, joint_k );
	    POS_j = [ POS_j POS_tmp ];
	    ORI_j = [ ORI_j ORI_tmp ];
	    //k= k+1;
          }        
	return { POS_j, ORI_j };
	} 
