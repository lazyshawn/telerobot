/***************************************************************

                SpaceDynX, pre-release

*****************************************************************

CROSS 		returns the vector cross product u x v

		global none
		uses   none

*****************************************************************/

	Func Matrix cross( u, v )
	Matrix u, v;
	{
	Matrix n;

	n = Z(3, 1);
	n(1) = u(2) * v(3) - u(3) * v(2);
	n(2) = u(3) * v(1) - u(1) * v(3);
	n(3) = u(1) * v(2) - u(2) * v(1); 

	return n;
	}
