/***************************************************************

                SpaceDynX, pre-release

****************************************************************

CALC_GJ		returns the generalized jacobian, GJ (6xn).

		input:
			A0 - orientation of the base wrt to inertia frame
                             (3 by 3 direction cosines matrix)
			q  - joint angles
			R0 - base position
			num_e - number of end-effector

		global Qi J_type BB SS SE S0
		global cc ic c0 ce
		global m0 inertia0 m inertia mass

		uses calc_hh, calc_jte, calc_jre,  f_kin_e, j_num, tilde

*****************************************************************/
	Func Matrix calc_gj( R0, A0, q, num_e )
	Matrix  R0, A0, q;
	Integer  num_e;	
	{
	Integer num_q, n, i;
	Matrix  Jtm, Jrm, Jm, Js, pe, tmp1, tmp2, tmp3, Hm, HH, Hs, joint, GJ;

// Number of links
	num_q = length( q );

// Calculation of inertia matrices, HH
	HH = calc_hh( R0, A0, q );

// calculate Jacobian and inertia matrices

	Jtm = calc_jte( R0, A0, q, num_e );
	Jrm = calc_jre( A0, q, num_e );
	Jm = [ [Jtm ][Jrm ]];
        
	{pe, tmp1} = f_kin_e( R0, A0, q, num_e );
	tmp3 = - tilde (pe - R0);
	Js = [[ I(3) tmp3 ][ Z(3) I(3) ]];

	Hs = HH(1:6,1:6);

	joint = j_num(num_e);
	n = length(joint);
	Hm = [];
	 for ( i=1; i<=n; i++ ) { 
		tmp2 = HH(1:6,6+ Integer(joint(i)));
		Hm = [ Hm tmp2 ];
	}

// Calculate the Generalized Jacobian

	GJ = Jm - Js * Hs~ * Hm;

	return GJ;
	}

////// EOF
