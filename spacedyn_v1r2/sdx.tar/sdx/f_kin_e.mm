/***************************************************************

                SpaceDynX, pre-release

*****************************************************************

F_KIN_E 	Foward Kinematics
		Caluculate the position/orientation of the end-point
		specified by 'num_e.'
		POS_e : 3x1 vector, ORI_e : 3x3 matrix.

		input:
			A0 - orientation of the base wrt to inertia frame
                             (3 by 3 direction cosines matrix)
			q  - joint angles
			R0 - base position
			num_e - number of end-effector

		global Qi J_type BB SE Qe
		global cc c0 ce

		uses calc_pos, calc_aa, rpy2dc, j_num

*****************************************************************/

	Func List f_kin_e( R0, A0, q, num_e)
	Integer num_e;
	Matrix  R0, A0, q;
	{   
	Matrix  A_i_EE;
	Matrix  AA, A_I_i, POS_e, RR, ORI_e, joint;
	Integer num_q, i, j, k, n;

        num_q = length(q);//Check number of all joints

	//Calculation of coordinate transformation matrices 
                                        //in the Inertial Frame
         AA = calc_aa( A0, q );          
 

	//Find joint connection from End-link to zero 
        joint = j_num(num_e);

	//Check number of the corresponding joints
        n = length(joint);
	k = Integer( joint(n) );

	//Calculate coordinate trasformation matrix of End-Effector
	
          for ( i = 1; i <= num_q; i++ ) {
            if ( SE(i) == 1 ) {
              A_i_EE = ( rpy2dc(Qe(1, k), Qe(2, k), Qe(3, k)) )'; 
              ORI_e = ( AA( :, k*3-2 : k*3 ) * A_i_EE );
            }
	  }                                                             

	//Calculation of position vectors in the Inertia Frame
        RR = calc_pos( R0, A0, q );

	//Calculate position vector of End-point
        A_I_i = AA( :, k*3-2 : k*3 );
        POS_e = ( RR(:, k) + A_I_i * ce(:, k) );
	
        return { POS_e, ORI_e } ;
	}





