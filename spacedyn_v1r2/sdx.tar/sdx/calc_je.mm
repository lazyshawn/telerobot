/***************************************************************

                SpaceDynX, pre-release

*****************************************************************

CALC_JE  	Calculation of the Jacobian Matrix 
			     for the endpoint given as 'number'

		input:
			A0 - orientation of the base wrt to inertia frame
                             (3 by 3 direction cosines matrix)
			q  - joint angles
			R0 - base position
			num_e - number of end-effector
		
		global Qi J_type BB SS SE S0 Qe
		global cc c0 ce
		global m0 inertia0 m inertia

		uses calc_jte, calc_jre, j_num

*****************************************************************/

	Func Matrix calc_je( R0, A0, q, num_e )
	Matrix  R0, A0, q;
	Integer num_e;	

	{
	Integer num_q, n, i, joint_i;
	Matrix  joint, JJ_te, JJ_re, JJ, Jacobian;

	num_q = length(q); //Num_E of links

	JJ_te = Z( 3, num_q ); //Calculation of Jacobian
	JJ_re = Z( 3, num_q ); 
        
	JJ_te = calc_jte( R0, A0, q, num_e ); 
	JJ_re = calc_jre( A0, q, num_e ); 
	JJ = [[JJ_te ][ JJ_re ]];

	//Find joint connection from the end-link to the 0-th link.
	joint = j_num(num_e);
	n = length(joint); 
        Jacobian = Z( 6, num_q ); 

	//Compose the Jacobian using the corresponding joints.
	  for ( i = 1; i <= n; i++ ) { 
            joint_i = Integer( joint(i) );
            Jacobian( 1:6, joint_i ) = JJ( 1:6, i );
            //i = i+1;
          } 
		
	return Jacobian;
	}

