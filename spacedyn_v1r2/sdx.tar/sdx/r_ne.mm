/***************************************************************

                SpaceDynX, pre-release

*****************************************************************

R_NE		Inverse Dynamic computation by the Recursive Newton-Euler method

                R_NE returns a generalized force, which consists of
		the reaction forces FF0, TT0 on link 0, and torque tau
 		of each joint.

		input:
			A0 - orientation of the base wrt to inertia frame
                             (3 by 3 direction cosines matrix)
			R0 - position of the base centroid
			q, qd, qdd  - joint angles, vel, and accelerations
			v0, vd0  - base velocity and acceleration
			w0, wd0  - base angular velocity and acceleration 
			Fe, Te   - external force and torque
		
                global Qi J_type BB SS SE S0
	        global cc c0 ce
	        global m0 inertia0 m inertia
	        global Gravity Ez

		uses calc_aa, calc_vel, calc_acc, cross

*****************************************************************/

      Func Matrix   r_ne( R0, A0, v0, w0, vd0, wd0, q, qd, qdd, Fe, Te )
      Matrix  R0, A0, v0, w0, vd0, wd0, q, qd, qdd, Fe, Te;
      {                    
	 Integer num_q, i, j, p, l, l2; 
         Matrix AA, RR, JJ_t, JJ_r, vd, wd, vv, ww; 
         Matrix  A_I_0, A_I_i,A_I_BB, FF0, TT0, FF, TT, Fj, Tj, F, T, in_i; 
         Matrix calc_acc(), tau, Force;
	 Integer SE_i;        

         num_q = length( q );    // Number of links
         tau =  Z( num_q,1 );

  // Calculation of coordinate transformation matrices 
         A_I_0 = A0;
	 AA = calc_aa( A0 , q );

  // Calculation of velocity vectors vv,wwGravity)
  //  NOTE:	vv,ww are in the Inertial frame
         { vv,ww } = calc_vel( v0, w0, A0, q, qd );

  // Calculation of acceleration vectors vd,wd
  //  NOTE:	vd,wd are in the Inertial frame
         { vd , wd } = calc_acc( v0 , w0 , vd0 , wd0 , A0 , q , qd , qdd );

  // Calculation of inertia force & torque of link 0
  // NOTE:	FF,TT(FF0,TT0) are in the Inertial frame.

         FF0 = m0 * (vd0-Gravity);
	 TT0 = (A_I_0*inertia0*A_I_0')*wd0 + cross( w0 , ((A_I_0*inertia0*A_I_0')*w0) );

  //  Calculation of inertia force & torque of link i
  //  from link 1 to n
  //  Single or multibody ?
 
         if (num_q == 0){	//  If a single body,
            FF = [];
            TT = [];
         }else{			// If a multibody system,
            for (i=1 ; i <= num_q ; i++ ){
                A_I_i  = AA(:,i*3-2:i*3);
                in_i = inertia(:,i*3-2:i*3);
		FF(:,i) = m(i) * (vd(:,i) - Gravity) ;
		TT(:,i) = (A_I_i*in_i*A_I_i') * wd(:,i) 
                          + cross( ww(:,i) , ((A_I_i*in_i*A_I_i')*ww(:,i)) ); 
             } //for
         }

   // Equilibrium of forces & torques on each link
   //  On the i-th link
 
         Fj = Z(3,num_q);
         Tj = Z(3,num_q);

         if (num_q != 0){

   // Multibody system
   //  from link n to 1
 
            p = Cols(cc);  //Calculation of position vectors
            p = p/num_q;

            for (i=num_q ; i>=1 ; i--){  

               l = p*(i-1) + i;

               F = Z(3,1);
	       T = Z(3,1);

               for (j=i+1 ; j <= num_q ; j++){

                  F =  F + SS(i,j)*Fj(:,j);

               }
           
//  SE_i = Integer( SE(i) );
//print SE(i);
// print Fe;
               Fj(:,i) = FF(:,i) + F + [SE(i)*Fe(:,i)](1);
             
               for (j=i+1 ; j <= num_q ; j++){                   
                  l2 = p*(i-1) + j; 
                  A_I_i = AA(:,i*3-2:i*3);
		  T =  T + SS(i,j)*( cross(A_I_i*(cc(:,l2)-cc(:,l)),Fj(:,j) ) + Tj(:,j) );

               }

               if (J_type(i) == "R"){

   // Rotational joint
 
                  Tj(:,i) = TT(:,i) + T - cross( A_I_i*cc(:,l),FF(:,i) ) ;

               }else{

    // Prismatic joint

                  Tj(:,i) = TT(:,i) + T + cross( A_I_i*(Ez*q(i))-A_I_i*cc(:,l) , FF(:,i) ) ; 
             
               }

            //   Tj(:,i) = Tj(:,i) + SE(i)*( cross(A_I_i*(ce(:,i)-cc(:,l)),Fe(:,i) ) + Te(:,i) ) ; 

            }   ////////////////

   // Equilibrium on the link 0 

            F = Z(3,1);
	    T = Z(3,1); 

            for (i=1 ; i <= num_q ; i++){
             
               if (S0(i) != 0){
		     
                  F =  F + S0(i)*Fj(:,i);

               }
      
            }

            FF0 = FF0 + F;

            for (i=1 ; i <= num_q ; i++){
    
               if (S0(i) != 0){
           
                  T = T + S0(i)*( cross( (A_I_0*c0(:,i)) , Fj(:,i) ) + Tj(:,i) );

               }
   
            }

            TT0 = TT0 + T;

         } //if (num_q != 0)      
         
// Calculation of torques of each joint  
   
    // Single body
         if (num_q == 0){
            tau = Z();
         }else{
   // Multi body system
 
            for (i=1 ; i <= num_q ; i++){    
               A_I_i = AA(:,i*3-2:i*3);
               if (J_type(i) == "R"){
   // Rotational joint
                   tau(i,1) = [(Tj(:,i)'*(A_I_i*Ez))](1);
               }else{
                   tau(i,1) = Fj(:,i)'*(A_I_i*Ez);
               }    //if
            }    //for
         }   //if(num_q == 0)

   // Compose a generalized force

   // Single or multibody ?
         if (num_q == 0){
            Force = [ FF0' TT0' ]';
         }else{
            Force = [ FF0' TT0' tau' ]';
         }	
  return Force;
  }

 
       
     
                 









