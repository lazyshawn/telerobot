/***************************************************************

                SpaceDynX, pre-release

*****************************************************************                                          
CZ(theta)	returns a 3x3 matrix representing a 
		rotation of theta radians around the Z axis.

		global none
		uses   none

*****************************************************************/


	Func Matrix cz(t)   
	Real t;

	{     
	Matrix zz;

	zz = [[   cos(t)    sin(t)   0 ]
	      [ ,-sin(t)    cos(t)   0 ]
	      [   0         0        1 ]];
	
	return zz;
	}
       
