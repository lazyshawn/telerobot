/***************************************************************

                SpaceDynX, pre-release

*****************************************************************


DC2EUL		Direction Cosine matrix to 3-1-3 EULER angles

	        [A B C] = DC2EUL(M) returns a vector
		of 3-1-3 Euler angles corresponding
		to the direction cosine matrix M.

		global  none
		uses	none

*****************************************************************/

	Func Matrix dc2eul( M )
	Matrix M                  
	{   
	Matrix euler;
	Real   s3,c3;
	Real   ph,t,ps;

      	euler = Z(3,1);      

	  if ( abs( M(1,3) ) < EPS && abs( M(2,3) ) < EPS )  {
   
	    euler(3) = 0;
	    euler(2) = atan2( M(2,3) , M(3,3) );
	    euler(1) = atan2( M(1,2) , M(1,1) );
   
	  }  else {
   
	    euler(3) = atan2( M(1,3) , M(2,3));
	    s3 = sin( euler(3) );
	    c3 = cos( euler(3) );
	    euler(2) = atan2( s3*M(1,3) + c3*M(2,3) , M(3,3) );
	    euler(1) = atan2( M(3,1) , (-M(3,2)) );               
	
	  } 

	return  euler;
	} 
 


       
