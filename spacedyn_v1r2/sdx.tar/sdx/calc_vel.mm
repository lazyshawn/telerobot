/***************************************************************

                SpaceDynX, pre-release

*****************************************************************

CALC_VEL	returns the link velocities vv and angular velocities ww 
                wrt the inertial frame (vv and ww are 3 by n vectors)
		

		input:
			A0 - orientation of the base wrt to inertia frame
                             (3 by 3 direction cosines matrix)
			q  - joint angles
			v0 - base velocity
			w0 - base angular velocity

		global Qi J_type BB
		global cc c0 Ez

		uses calc_aa, cross

*****************************************************************/

	Func List calc_vel( v0 , w0 , A0 , q ,qd )
	Matrix  v0 , w0 , A0 , q ,qd;
	{
	Matrix  vv, ww, cc_ii, cc_Bi, A_I_i, A_I_0, A_I_BB, AA;
	Integer i, k, l, j, BB_i, num_q ,p;

	num_q = length(q);  //Number of links

	  if ( num_q == 0 ) {  //Single or multi body ?
            vv = [];          //If a Single body,
	    ww = [];
	  } else {            //If a Multi body system,

	//Calculation of coordinate transfromation matrices 
	    A_I_0 = A0;
	    AA = calc_aa( A0, q );

	//Calculation of velocity vectors vv,ww
            p = Cols(cc);
            p = p/num_q; 

            for ( i = 1; i <= num_q; i++ ) {
              cc_ii = cc( :, p*(i-1)+i );               
              BB_i = Integer( BB(i) );

	//Check the link connection:
                       //Is the lower one of this link, 0 ?
              if( BB_i==0 ) {
              
	//Current (i-th) link connects to the 0-th link
	        A_I_i = AA( :, i*3-2 : i*3 );

	//Rotational joint
	        if ( j_type(i)=="R" ) {
                  ww(:,i) = w0 + A_I_i * Ez * qd(i);
                  vv(:,i) = v0 
	                      + cross( w0,(A_I_0 * c0(:,i)) ) 
                              - cross( ww(:, i), (A_I_i * cc_ii) );
              
	        } else {

	//Prismatic joint
          	  ww(:,i) = w0;
		  vv(:,i) = v0 + cross( w0, (A_I_0*c0(:,i)) ) 
				  - cross( ww(:,i), (A_I_i * cc_ii) ) 
				  + cross( ww(:,i), (A_I_i * Ez*q(i)) ) 
				  + A_I_i * Ez * qd(i);

	        }
			
              } else {
                         
                cc_Bi = cc( :, p*(BB_i-1)+i );

	//Current (i-th) link doesn't connect to the 0-th link
	        A_I_BB = AA( :, BB_i*3-2 : BB_i*3 );
	        A_I_i  = AA( :, i*3-2 : i*3 ); 

	//Rotational joint
	        if ( j_type(i)=="R" ) {
		  ww(:,i) = ww( :, BB_i ) + A_I_i * Ez * qd(i);
		  vv(:,i) = vv( :, BB_i ) 
			      + cross( ww(:, BB_i), (A_I_BB * cc_Bi) ) 
                              - cross( ww(:,i), (A_I_i * cc_ii) );	  
	
	        } else {

	//Prismatic joint
		  ww(:,i) = ww(:, BB_i);
		  vv(:,i) = vv(:, BB_i) 
		  	      + cross( ww(:, BB_i), (A_I_BB * cc_Bi) ) 
			      - cross( ww(:,i), (A_I_i * cc_ii) ) 
			      + cross( ww(:,i), (A_I_i * Ez*q(i)) ) 
					         + A_I_i * Ez * qd(i);
	        }
	      }
            }
	  }
	return {vv, ww};
	}