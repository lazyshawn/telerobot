/***************************************************************

                SpaceDynX, pre-release

****************************************************************

CALC_ACC	returns the accelation in the inertia frame
		for link 1 to n.
		
		input:
			A0 - orientation of the base wrt to inertia frame
                             (3 by 3 direction cosines matrix)
			q, qd, qdd  - joint angles, vel, and accelerations
			v0, vd0  - base velocity and acceleration
			w0, wd0  - base angular velocity and acceleration 

		uses	calc_aa,  calc_vel, cross
		global  Qi, j_type, BB, cc, c0, Ez

*****************************************************************/

      Func List calc_acc( v0, w0, vd0, wd0, A0, q, qd, qdd )
      Matrix v0, w0, vd0, wd0, A0, q, qd, qdd; 
     {
	Integer num_q, i, p, l, l2, BB_i; 
        Matrix AA, RR, JJ_t, JJ_r, vd, wd, vv, ww; 
        Matrix A_I_0, A_I_i, A_I_BB; 

        num_q = length( q );    // Number of links

        if( num_q == 0 ){         //Single or multibody ?
     // If single body

           vd = [];
           wd = [];

         }else{

     // If multibody system
     // Calculation of coordinate transfromation matrices 

           A_I_0 = A0;
           AA = calc_aa( A0, q );

     // Calculation of velocity vectors

           { vv , ww } = calc_vel( v0, w0, A0, q, qd );

           p = Cols(cc);  //Calculation of position vectors
           p = p/num_q;

     //  Calculation of acceleration vectors vd,wd

           for (i = 1; i <= num_q; i++){

              BB_i = Integer( BB(i) );      
              l = p * (i - 1) + i; 
            
     // Check the link connection: Is the lower one of this link, 0 ?

              if ( BB_i == 0 ){

     // If the i-th link connects with 0-th link

                  A_I_i = AA(:,i*3-2:i*3);
 
     // Rotational joint

                  if ( j_type(i) == "R" ){

                     wd(:,i) = wd0 + cross( ww(:,i) , (A_I_i * Ez * qd(i)) ) + A_I_i * Ez * qdd(i);
                     vd(:,i) = vd0 + cross( wd0 , (A_I_0 * c0(:,i)) ) 
                               + cross( w0 , cross(w0 , (A_I_0*c0(:,i)) ) ) 
                               - cross( wd(:,i) , (A_I_i*cc(:,l)) ) 
                               - cross( ww(:,i) , cross(ww(:,i) , (A_I_i*cc(:,l))) );

                  }else{
 
                     wd(:,i) = wd0;
		     vd(:,i) = vd0 + cross( wd0 , (A_I_0*c0(:,i)) ) 
                               + cross( w0 , cross(w0 , (A_I_0*c0(:,i))) ) 
                               + cross( wd(:,i),(A_I_i*Ez*q(i)) ) 
                               + cross( ww(:,i),cross(ww(:,i),(A_I_i*Ez*q(i))) ) 
                               + 2*cross( ww(:,i),(A_I_i*Ez*qd(i)) ) + ( A_I_i*Ez*qdd(i) )
                               - cross( wd(:,i),(A_I_i*cc(:,l)) ) 
                               - cross( ww(:,i),cross(ww(:,i),(A_I_i*cc(:,l))) ) ;

                  }
              }else{

     // Current (i-th) link doesn't have connection with the 0-th link
  
                  A_I_BB = AA( :, BB_i*3-2 : BB_i*3 );
	          A_I_i  = AA( :, i*3-2 : i*3 );

     // Rotational joint

                  if ( J_type(i) == "R" ){

                     l2 = p*( BB_i-1 ) + i;

                     wd(:,i) = wd(:,BB_i) + cross( ww(:,i),(A_I_i*Ez*qd(i)) ) + ( A_I_i*Ez*qdd(i) );
	             vd(:,i) = vd(:,BB_i) + cross( wd(:,BB_i ),(A_I_BB*cc(:,l2)) ) 
                               + cross( ww(:,BB_i ),cross(ww(:,BB_i),( A_I_BB*cc(:,l2))) ) 
                               - cross( wd(:,i),(A_I_i*cc(:,l)) ) 
                               - cross( ww(:,i),cross(ww(:,i),(A_I_i*cc(:,l))) );

                  }else{

     // Prismatic joint

                      l2 = p*( BB_i-1 ) + i;

                      wd(:,i) = wd(:,BB_i);
                      vd(:,i) = vd(:,BB_i) + cross( wd(:,BB_i),(A_I_BB*cc(:,l2)) ) 
                                + cross( ww(:,BB_i),cross(ww(:,BB_i),(A_I_BB*cc(:,l2))) ) 
                                + cross( wd(:,i),(A_I_i*Ez*q(i)) ) 
                                + cross( ww(:,i),cross(ww(:,i),( A_I_i*Ez*q(i))) ) 
                                + 2*cross( ww(:,i),(A_I_i*Ez*qd(i)) ) + ( A_I_i*Ez*qdd(i) ) 
                                - cross( wd(:,i),(A_I_i*cc(:,l)) ) 
                                - cross( ww(:,i),cross(ww(:,i),(A_I_i*cc(:,l))) );
 
                  }
              }
           }        //for
         }
      return { vd, wd };
     }   






