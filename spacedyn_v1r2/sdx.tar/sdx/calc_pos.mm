/***************************************************************

                SpaceDynX, pre-release

*****************************************************************

CALC_POS	returns the link centroid position vectors wrt the 
		inertia frame (RR is a 3 by n matrix)

		input:
			A0 - orientation of the base wrt to inertia frame
                             (3 by 3 direction cosines matrix)
			q  - joint angles
			R0 - base position

		global Qi J_type BB
		global cc c0 Ez

		uses  calc_aa

*****************************************************************/

	Func Matrix calc_pos( R0 , A0 , q )
	Matrix R0, A0, q;
	{
	Matrix  AA, A_0_i, A_I_0, RR, A_I_i, A_I_BB; 
	Integer num_q, i, j, k, l, p, d, BB_i, l2;

        num_q = length(q);// Number of links

          if ( num_q == 0 ) { //Single or multi body ?
            RR = [];        //If a Single body,
	
          } else {          //If a Multi body system,

	//Calculation of coordinate transfromation matrices 
            AA = calc_aa( A0, q );
     
            p = Cols(cc);  //Calculation of position vectors
            p = p/num_q;
           
            for ( i = 1; i <= num_q; i++ ) {              
              BB_i = Integer( BB(i) );        
              A_I_i = AA( :, i*3-2 : i*3 );          

	//Check the link connection:
                          //Is the lower one of this link, 0 ? 
              if ( BB_i==0 ) { //Current (i-th) link connects to the 0-th link
                   A_I_0 = A0;
                   l = p*(i-1) + i; 
                 
	           if ( j_type(i) == "R" ) {  
                          RR(:,i) = R0 + A_I_0*c0(:,i) - A_I_i*cc(:,l);                                
                   } else {  //Prismatic joint
        	          RR(:,i) = R0 + A_I_0*c0(:,i)
				    + A_I_i*( Ez*q(i) - cc(:,l) ); 
                          }
               } else {    //Current (i-th) link doesn't connect to the 0-th link
                   l2 = p*(BB_i-1) + i;
                    l = p*(i-1) + i; 
                   
                   A_I_BB = AA( :, BB_i*3-2 : BB_i*3 );
               
                   if ( j_type(i) == "R") { //Rotational joint
                        RR(:,i) = RR( :, BB_i ) + A_I_BB*cc(:,l2) - A_I_i*cc(:,l);  	
                
                   } else { // Prismatic joint
                 
	                  RR(:,i) = RR( :, BB_i ) + A_I_BB*cc(:, l)
                                        + A_I_i*( Ez*q(i) - cc(:,l) );
                          }
              }
            }
          }	
	return RR;
	}