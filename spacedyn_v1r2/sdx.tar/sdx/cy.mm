/***************************************************************

                SpaceDynX, pre-release

*****************************************************************                                          
CY(theta)	returns a 3x3 matrix representing a 
		rotation of theta radians around the Y axis.

		global none
		uses   none

*****************************************************************/

	Func Matrix cy(t)         
	Real t;

	{
	Matrix zz;

	zz = [[ cos(t)   0   ,-sin(t) ] 
	      [ 0        1     0      ]
	      [ sin(t)   0     cos(t) ]];

	return zz;
	}



