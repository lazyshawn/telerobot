/*************************************************************
 
  - a 3-link arm on a floating base: 
  - motion of a separate joint specified by the user
  - generates a text file test.txt with end-point coordinates
  
  - based on a program written by Takashi Yanagiya,
                    Hirosaki University, June 1999

*************************************************************/

extern Matrix Qi,Qe,BB,SE,SS,S0,cc,c0,ce,Ez;
extern Matrix m,inertia0,inertia;
extern Integer m0;
extern Real mass;
extern String j_type;

Func void main()
{
/****** Declaration ******************************************/

  List f_kin_e();
  Matrix rpy2dc(),calc_aa(),calc_pos(),tilde();
  Matrix cx(),cy(),cz(),calc_hh(),calc_jt(),calc_jr();
  Matrix cross();
  Integer j_num();

  Matrix v0,w0,R0,A0,q,ePos,rePos,HH,Hb,Hbm,qDot,vw;
  List a,lst;
  Integer num_e,i,ii,i1,i2,fpw,fpr,voc;
  Real dltt,r,dd;

/****** Definition ********************************************/
 
  j_type = ["R" "R" "R"];

  c0 = [[,-0.785 0 0]
        [,-0.29  0 0]
        [  1     0 0]];

  cc = Z(3, 9);

  cc(:, 0 * 3 + 1) = [  0     0    ,-0.175]'; // c11
  cc(:, 1 * 3 + 2) = [,-0.435 0      0    ]'; // c22
  cc(:, 2 * 3 + 3) = [,-0.315 0      0.275]'; // c33

  cc(:, 0 * 3 + 2) = [  0     0.275  0.175]'; // c12
  cc(:, 1 * 3 + 3) = [  0.435 0      0    ]'; // c23

  ce = [[ 0   0   0.315]
        [ 0   0   0    ]
        [ 0   0   0    ]];

  Ez = [0 0 1]';
  BB = [ 0 1 2];

  SS = [[,-1   1   0]
        [ 0  ,-1   1]
        [ 0    0 ,-1]];
  S0 = [ 1 0 0];
  SE = [ 0 0 1];

  q = [0 0 0]';

  Qi = [[ 0  ,-PI/2   0  ]
        [ 0    0      0  ] 
        [ 0  ,-PI/2  PI/2]];
  Qe = Z(3);
  A0 = I(3);

  R0 = [0 0 0]';
             
  num_e = 1;

  m = [ 35.01 22.45 21.89 ];
  m0 = 2552;
  mass = m(1)+m(2)+m(3);
  inertia0 = [[ 6230.000    52.020     4.324 ]
              [   52.020  3540.000  ,-27.000 ]
              [    4.324  ,-27.000  7268.000 ]];

  inertia = [[ 0.2452 0 0   0.1 0 0     0.1 0 0]
             [ 0 0.2452 0   0 1.315 0   0 0.7115 0]
             [ 0 0 1.692    0 0 3.752   0 0 2.528]];

  dltt = 0.01;
  HH = Z(9);
  Hb = Z(6);
  Hbm = Z(6,3);

  v0 = Z(3,1);
  w0 = Z(3,1);

  qDot = Z(3,1);

/****** Input *****************************************************/
 
  clear;
  printf("Input No. of joint to be moved (1-3): \n");

  i1 = getch() - 48;
  if(i1 > 0 && i1 < 4){
    printf("Joint %d is moved.\n",i1);
  } 
  else{
    error("ERROR:Invalid number!!\n");
  }

  printf("and Input direction of motion (1 or 2)\n");
  printf("(cw->2, ccw->1):\n");
  i2 = getch() - 48;
  if(i2 == 1){
    voc = 1;
    printf("Direction is counter clock wise.\n");
  }
  else{
    if(i2 == 2){
      voc = -1;
      printf("Direction is clock wise.\n");
    }
    else{
      error("ERROR:Invalid value!!\n");
    }
  }

/****** Input Output Files ************************************/

  if((fpw = fopen("test.txt","w")) < 0){
    error("Can't open file.\n");
  }
  for(r = 0;r < 100;r = r + 1){
    qDot(i1,1) = voc;   // voc : velocity of joint
    q(i1,1) = qDot(i1,1) * dltt * r;
    HH = calc_hh(R0,A0,q);
    for(i = 1;i < 7;i = i + 1){
      for(ii = 1;ii < 7; ii = ii + 1){
        Hb(ii,i) = HH(ii,i);
      }
    }
    for(i = 1;i < 4;i = i + 1){
      for(ii = 1;ii < 7;ii = ii + 1){
        Hbm(ii,i) = HH(ii,i + 6); 
      }
    }

    vw = -inv(Hb) * Hbm * qDot;
    v0(1,1) = vw(1,1);
    v0(2,1) = vw(2,1);
    v0(3,1) = vw(3,1);
    R0 = R0 + v0 * dltt;
 
    a = f_kin_e(R0, A0, q, num_e);
    ePos = a(1,Matrix);
    fprintf(fpw,"%s%3d  %lf  %lf  %lf\n","No.",Integer(r)
              ,ePos(1,1),ePos(2,1),ePos(3,1));
  }
  
  fclose(fpw);

  rePos = Z(3,100);

  if((fpr = fopen("test.txt","r")) < 0){
    error("Can't open file.\n");
  }
  for(i = 1;i < 101;i = i + 1){
    lst = fscanf(fpr,"%s%3d  %lf  %lf  %lf\n");
    rePos(1,i) = lst(3,Real);
    rePos(2,i) = lst(4,Real);
    rePos(3,i) = lst(5,Real);
  }

  fclose(fpr);

/****** Graphic ***********************************************/

  /**** X-Y plane **********************************/
  mgplot_options(1,"-geometry 500x500");
  mgplot_title(1,"X-Y plane");
  mgplot_xlabel(1,"X");
  mgplot_ylabel(1,"Y");
  mgplot_grid(1,1);
  mgplot_key(1,1);
  mgplot(1,rePos(1,:),rePos(2,:),{"end-point-path"});


  /**** X-Z plane **********************************/
  mgplot_options(2,"-geometry 500x500");
  mgplot_title(2,"X-Z plane");
  mgplot_xlabel(2,"X");
  mgplot_ylabel(2,"Z");
  mgplot_grid(2,1);
  mgplot_key(2,1);
  mgplot(2,rePos(1,:),rePos(3,:),{"end-point-path"});

  printf("Press any key\n");
  dd = getch();
}
  



