/***************************************************************

                SpaceDynX, pre-release

*****************************************************************

TILDE	a skew-symmetric operator
	B=A~;
	B*A=0;
	
	global none
	uses   none

*****************************************************************/

	Func Matrix tilde( A )
	Matrix  A;
	{
	Matrix B;

	B = [[   0.0      ,-A(3)   ,A(2) ]
	     [   ,A(3)   0.0      ,-A(1) ]
	     [ ,-A(2)   ,A(1)   0.0      ]];
	return B;
	}