/***************************************************************

                SpaceDynX, pre-release

*****************************************************************                                          
CX(theta)	returns a 3x3 matrix representing a 
		rotation of theta radians around the X axis.

		global none
		uses   none

*****************************************************************/


	Func Matrix cx(t)       
	Real t;
	
	{    
	Matrix zz;
	
	zz = [[ 1    0       0      ]
	      [ 0    cos(t)  sin(t) ]
	      [ 0  ,-sin(t)  cos(t) ]];
	
	return zz;
	}


