/***************************************************************

                SpaceDynX, pre-release

*****************************************************************

DC2RPY		Direction Cosine matrix to roll/pitch/yaw angles

	        [A B C] = DC2RPY(M) returns a vector
		of RPY angles corresponding
		to the direction cosine matrix M.

		global  none
		uses	none

*****************************************************************/


	Func Matrix dc2rpy( M )      
	Matrix M;                  

	{   
	Matrix rpy;
	Real   c3,s3;
	Real   r,p,y;
      
	rpy = Z(3,1);     
	
 	  if ( abs( M(2,1) ) < EPS && abs( M(1,1) ) < EPS ) {
	
	    rpy(3) = 0;
	    rpy(2) = atan2( M(3,1) , M(1,1) );
	    rpy(1) = atan2( M(2,3) , M(2,2) );
	
	  } else {
	
	    rpy(3) = atan2( ( -M(2,1)) , M(1,1) );
	    c3 = cos( rpy(3) );
	    s3 = sin( rpy(3) );
	    rpy(2) = atan2( M(3,1) , c3 * M(1,1) - s3 * M(2,1) );
	    rpy(1) = atan2( ( -M(3,2)) , M(3,3) );
	
	  }

	return rpy;
	}       















