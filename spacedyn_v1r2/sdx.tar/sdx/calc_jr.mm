/***************************************************************

                SpaceDynX, pre-release

*****************************************************************

CALC_JR 	Rotational Jacobians w.r.t. link centroid

		input:
			A0 - orientation of the base wrt to inertia frame
                             (3 by 3 direction cosines matrix)
			q  - joint angles

		global Qi j_type BB SS SE S0
		global cc c0 ce
		global m0 inertia0 m inertia

		uses calc_aa

*****************************************************************/

	Func Matrix calc_jr( A0 , q  )
	Integer number;
	Matrix A0, q;
	{	
	Integer num_q, i, k, n, j, BB_j;
	Matrix AA, joint, A_I_i;   
	Matrix JJ_r,A_I_0, A_I_j; 	

// Number of links

	num_q = length( q );
	
// Calculation of the coordinate transfromation matrices 

	A_I_0 = A0;
	AA = calc_aa( A0 , q );

// Calculation of translational jacobians

	JJ_r = Z( 3, num_q*num_q );

// Single or multi body ?
   
	if( num_q == 0) {

// If a Single body,

		JJ_r = [];

// If a Multi body system,

	  } else {

	   for ( i = 1 ; i <= num_q ; i++ ) {

                         j = i; 
			                                 
	      while ( j > 0 ) {

	        A_I_j  = AA( :, j*3-2:j*3 );
//print A_I_j ;
	        if( j_type(j) == "R") {

// Rotational joint

		  JJ_r( :, (i-1)*num_q+j ) = A_I_j * Ez;

      
                } else {
                
// Prismatic joint

		  JJ_r( :, (i-1)*num_q+j ) = [0 0 0]';
	      
                }
	       
	          j =  Integer(BB(j));
               
	      }
            }
	  }

	return JJ_r;
	}