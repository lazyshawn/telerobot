/***************************************************************

                SpaceDynX, pre-release

*****************************************************************

CALC_JT 	Translational Jacobians w.r.t. link centroid

		input:
			A0 - orientation of the base wrt to inertia frame
                             (3 by 3 direction cosines matrix)
			q  - joint angles
			R0 - base position

		global Qi J_type BB SS SE S0
		global cc c0 ce Ez
		global m0 inertia0 m inertia

		uses calc_pos, calc_aa, cross

*****************************************************************/

	Func Matrix calc_jt( R0, A0, q  )
	Matrix R0, A0, q;
	Integer number;
	{	
	Matrix joint; 
	Integer num_q, n, k, i, j, p, l, BB_j;
	Matrix  RR, AA, JJ_t;
	Matrix  A_I_0, A_I_j; 

	num_q = length(q);  //Number of links

        p = Cols(cc);
        p = p/num_q;

	//Calculation of coordinate transformation matrices 
	A_I_0 = A0;
	AA = calc_aa( A0, q );

	//Calculation of position vectors
	RR = calc_pos( R0, A0, q );

	//Calculation of translational Jacobians
	JJ_t = Z( 3, num_q * num_q );

	  if( num_q == 0 ) { //Single or multibody ?
	    JJ_t = [];      //a single body
	  } else {          //a multibody system

        for ( i=1; i <= num_q; i++ ) {         
              j = i ;              	    
              while ( j > 0 ) {                  
		  l = p * (j-1) + j;
		  A_I_j  = AA( : ,j*3-2:j*3 );
	          if ( j_type(j) == "R") {  //Rotational joint              
				JJ_t(:,(i-1)*num_q+j) = cross( (A_I_j * Ez), ( RR(:,i)  
			                             - RR(:,j) - A_I_j * cc(:,l) ) ); 

           	  } else {  //Prismatic joint
		         JJ_t( :, (i-1)*num_q+j ) = A_I_j * Ez ;
	                 }
	        j = Integer( BB(j) );
	     }
	   }
	 }
	return JJ_t;
	}


