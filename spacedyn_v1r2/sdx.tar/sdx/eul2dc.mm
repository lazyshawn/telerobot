/***************************************************************

                SpaceDynX, pre-release

*****************************************************************


EUL2DC		3-1-3 Euler angles to direction cosine matrix

		EUL2DC(Z1,X2,Z3) returns a direction cosine matrix 
		for the specified Euler angles.  
		These correspond to rotations about the
		Z, X, Z axes respectively.

		global	none
		uses	cx, cz

*****************************************************************/

	Func Matrix eul2dc( ph, t, ps )    
	Real ph, t, ps; 
	{   
	Matrix M;                        
	M = cz (ps) * cx (t) * cz (ph);
	return M;
	}
                                          
                                   
                                    
   
 
  
        
            

         
  