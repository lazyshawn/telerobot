/***************************************************************

                SpaceDynX, pre-release

****************************************************************

CALC_HH		returns the inertia matrices HH (6+n)x(6+n).
	 
		input:
			A0 - orientation of the base wrt to inertia frame
                             (3 by 3 direction cosines matrix)
			q  - joint angles
			R0 - base position
		
		global Qi J_type BB SS SE S0
		global cc c0 ce
		global m0 inertia0 m inertia mass

		uses calc_jr, calc_jt, calc_pos, calc_aa, tilde;

*****************************************************************/


        Func Matrix calc_hh( R0, A0, q )
        Matrix R0, A0, q;       
        {
	Integer num_q, i;
	Matrix AA, A_I_O, RR, JJ_t, JJ_r, Rm, Rg, wr0g, tilde_r0i, tilde_wr0g ;
        Matrix JJ_tg, HH, HH_w, HH_wq, HH_q, A_I_0, A_I_i, wE, r0i; 

        num_q = length( q );            //Number of links
      
        A_I_0 = A0;                     //Calculation of coordinate transformation matrices 
        AA  = calc_aa( A0 , q );    
        RR  = calc_pos( R0 , A0 , q ); //Calculation of position vectors
	JJ_t = calc_jt( R0 , A0 , q  );//Calculation of partial translational & rotational jacobian
	JJ_r = calc_jr( A0 , q  ); 
        
//Calculation of the position of gravity centroid, Rg
 
	 Rm = Z(3,1);                        //initial setting 
         if (num_q !=  0){		    //Single or multi body ?          
            for (i=1 ; i <= num_q ; i++){   //Multi body system
                Rm = Rm + m(i) * RR(:,i);  
             }
         }  
	Rm = Rm + m0 * R0; 
	Rg = Rm / mass;  

	wE = mass * I(3,3);      //Calculation of HH matrix

	wr0g = (Rg-R0) * mass; 

	JJ_tg = Z(3,num_q);
	HH_w  = Z(3,3);
	HH_wq = Z(3,num_q);
       	HH_q  = Z(num_q,num_q);

        if (num_q != 0){            //Single or multi body ?
             for(i=1 ; i <= num_q ; i++){  // Multi body system
             
			r0i = RR(:,i) - R0;
			tilde_r0i = tilde(r0i);
			A_I_i = AA(:,i*3-2:i*3);
			JJ_tg = JJ_tg + m(i)*JJ_t(:,(i-1)*num_q+1:i*num_q);
			HH_w  = HH_w + A_I_i*inertia(:,i*3-2:i*3)*A_I_i' 
				+ m(i)*(tilde_r0i)'*(tilde_r0i);
			HH_wq = HH_wq 
				+ (A_I_i*inertia(:,i*3-2:i*3)*A_I_i')*JJ_r(:,(i-1)*num_q+1:i*num_q) 
				+ m(i) * (tilde_r0i) * JJ_t(:,(i-1)*num_q+1:i*num_q);
			HH_q  = HH_q 
				+ JJ_r(:,(i-1)*num_q+1:i*num_q)'* 
				(A_I_i*inertia(:,i*3-2:i*3)*A_I_i')* 
				JJ_r(:,(i-1)*num_q+1:i*num_q) 
				+ m(i) * JJ_t(:,(i-1)*num_q+1:i*num_q)'*JJ_t(:,(i-1)*num_q+1:i*num_q);
                }
          }
          
	  HH_w = HH_w + (A_I_0*inertia0*A_I_0');

          tilde_wr0g = tilde(wr0g);
          
	  if (num_q == 0){            //Single or multibody?
                // A single body
		HH = [[	wE		tilde_wr0g'    ]
		      [	tilde_wr0g	HH_w		]];
          } else {
                 // Multibody system
	         HH = [[ wE		tilde_wr0g'	JJ_tg  ]
	               [ tilde_wr0g	HH_w		HH_wq  ]
	               [ JJ_tg'		HH_wq'		HH_q   ]];
	  }
        
       return HH;

}










