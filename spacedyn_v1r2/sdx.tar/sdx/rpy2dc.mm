/***************************************************************

                SpaceDynX, pre-release

*****************************************************************

RPY2DC		Roll/pitch/yaw angles to direction cosine matrix

		RPY2DC(R,P,Y) returns a 3x3 direction cosine matrix
		for the specified roll/pitch/yaw angles.  
		These correspond to rotations about the X, Y, Z axes respectively.


		global	none
		uses	cx, cy, cz
*****************************************************************/


	Func Matrix rpy2dc( r, p, y )
	Real r, p, y;
	{   
	Matrix M;
        
	M = cz(y) * cy(p) * cx(r);
        
	return M;
	}