/***************************************************************

                SpaceDynX, pre-release

****************************************************************

CALC_AA         returns the coordinate tranformation matrices AA.
		AA is a 3 by 3n matrix, a collection of 
		                         A_I_1, A_I_2, ... A_I_n
		
		input:
			A0 - orientation of the base wrt to inertia frame
                             (3 by 3 direction cosines matrix)
			q  - joint angles
  
		global Qi j_type BB
		uses  rpy2dc
 
*****************************************************************/

	Func Matrix calc_aa( A0 , q )
	Matrix A0, q;
	{ 
	Matrix  AA, A_0_i, A_I_0, A_BB_i;
	Integer num_q, i, BB_i;                                                     

          num_q = length(q);  //Number of links 
          if ( num_q == 0 ) {  //single  body                                                    AA = [];     
     	  } else {             //multibody system

	//Calculation of coordinate transformation matrices
	    A_I_0 = A0;           
      	    for ( i = 1; i <= num_q; i++ ) {
              BB_i = Integer( BB(i) );

	//Check the link connection:
              if ( BB_i==0 ) {	//Current (i-th) link connects to the 0-th link
                if ( j_type(i) == "R" ) {		//Rotational joint 
                  A_0_i=( rpy2dc( Qi(1,i), Qi(2,i), Qi(3,i) + q(i))' );   
                } else {				//Prismatic joint  
                  A_0_i =( rpy2dc( [ Qi(:,i) ] )' ); 
                }
	        AA( :, (i*3-2) : (i*3) ) = A_I_0 * A_0_i;
              } else {   //Current (i-th) link doesn't connect to the 0-th link
                if ( j_type(i) == "R" ) {       	//Rotational joint
                  A_BB_i = ( rpy2dc( Qi(1,i), Qi(2,i), Qi(3,i)+q(i) )' );
	        } else {				//Prismatic joint
                  A_BB_i = ( rpy2dc( Qi(1,i), Qi(2,i), Qi(3,i) )' );
                }           	       
                AA( :,( i*3 - 2 ) : ( i*3 ) )
		             = AA( :, (BB_i*3-2 ) : ( BB_i*3 ) ) * A_BB_i;
              }
            }
          }
	return AA;
	}























