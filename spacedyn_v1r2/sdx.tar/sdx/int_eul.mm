/***************************************************************

                SpaceDynX, pre-release

*****************************************************************

INT_EU		returns velocity & position vectors 
		of each link of the system in the inertia frame.
		It uses a simple, most primitive  Euler integration.

		input:
			A0 - orientation of the base wrt to inertia frame
                             (3 by 3 direction cosines matrix)
			R0 - position of the base centroid
			q, qd, qdd  - joint angles, vel, and accelerations
			v0, vd0  - base velocity and acceleration
			w0, wd0  - base angular velocity and acceleration 
		
		NOTE:v0,w0,vd0,wd0 are in the inertia frame.

		global d_time
		
		uses tilde

*****************************************************************/

	Func List int_eul( R0, A0, q, v0, w0, qd, vd0, wd0, qdd )
	Matrix             R0, A0, q, v0, w0, qd, vd0, wd0, qdd;
	{
	Integer num_q; 
	Matrix q_n, qd_n, R0_n, v0_n, w0_n, C0, dC0, C0_n ;

	num_q = length(q); // Number of links

	// Integration of q and qd

	// Single or multi bodies ?

        if( num_q == 0) { // Single or multi bodies ?

	// Single body
     	  q_n = []; 
          qd_n = [];

	} else {		

	// Multi bodies
	  qd_n = qd + qdd * d_time;
     	  q_n  = q  + qd  * d_time; 
	}

	// Integration of v0, R0, and A0
	R0_n = R0 + v0  * d_time;
	v0_n = v0 + vd0 * d_time;
        w0_n = w0 + wd0 * d_time; 

	// Note that C0 is the direction cosines of body 0
	C0 = ( A0 )';       // C0 = ( A0 )^T
        

	// dC0 is the time derivative of C0
	dC0 = (tilde(w0))' * C0; 
	C0_n = C0 + dC0 * d_time;

	// outputs
	R0 = R0_n;
	A0 = ( C0_n )';
	v0 = v0_n;
	w0 = w0_n;
	q  = q_n;
	qd = qd_n;


	return {R0,A0,q,v0,w0,qd};
	}	




