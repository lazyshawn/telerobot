/***************************************************************

                SpaceDynX, pre-release

*****************************************************************

J_NUM	        Find joint connection from a given end-link, 
		specified by 'num_e', to the 0-th link

		global	BB SE
		uses	none

*****************************************************************/

	Func Matrix j_num(num_e)
	Integer num_e;   
	{	    
	Integer n, j, i, j_number;
	Matrix  ie, joint, connection;                                             
	n = length(SE);
	j = 0;
	  for ( i=1; i<=n; i++ ) {          
            if ( SE( i )==1 ) {
              j = j+1;
              ie(j) = i;
            }
          }   
	i = Integer( ie(num_e) );
	j_number = Integer( BB(i) );
	connection = [ Integer( ie(num_e) ) ];
	  while ( j_number != 0 ) {
            connection = [ j_number connection ];
            j_number = Integer( BB(j_number) );
          }
	joint = connection;
        
	return joint;
	}