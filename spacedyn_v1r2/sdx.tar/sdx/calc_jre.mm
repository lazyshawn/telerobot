/***************************************************************

                SpaceDynX, pre-release

*****************************************************************

CALC_JRE	Translational Jacobians w.r.t. the End-point
					  specified by 'num_e'

		input:
			A0 - orientation of the base wrt to inertia frame
                             (3 by 3 direction cosines matrix)
			q  - joint angles
			num_e - number of end-effector

		global Qi J_type BB SS SE S0 Qe
		global cc c0 ce
		global m0 inertia0 m inertia

		uses calc_aa, j_num

*****************************************************************/

	Func Matrix calc_jre( A0 , q, num_e )
	Matrix  A0, q;
	Integer num_e;
	{
	Matrix  joint, JJ_re, AA, A_I_i; 
	Integer num_q, n, k, i, joint_i;

	num_q = length(q); //Number of links

	//Calculation of coordinate transfromation matrices 
	AA = calc_aa( A0, q );

	//Find joint connection from the end-link to zero
	joint = j_num(num_e);

	n = length(joint);   //Check number of joints
	k = Integer( joint(n) );
      
	  if( num_q == 0 ) {  //Single or multi body ?
	    JJ_re = [];      //If a Single body,
	  } else {           //If a Multi body system,
            JJ_re = [];
	  
            for ( i=1; i<=n; i++ ) {
              joint_i = Integer( joint(i) );
	      A_I_i = AA( :, joint_i*3-2 : joint_i*3 );
	    
              if ( j_type( joint_i ) == "R") {  //Rotational joint
	        JJ_re = [ JJ_re A_I_i*Ez ];
	      } else {				//Prismatic joint	
	        JJ_re = Z( 3, n );
              }
	      //i = i+1;
	    }		
	  }	
	return JJ_re;
	}